package interfaces;

public interface MoveAble {
	int move();
}
