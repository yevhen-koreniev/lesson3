package interfaces;

public interface SwimAble {
	int swim();
}
