package interfaces;

public interface FlyAble {
	int fly();
}
